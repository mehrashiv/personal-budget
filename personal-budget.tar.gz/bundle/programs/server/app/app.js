var require = meteorInstall({"lib":{"collections.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/collections.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Category = new Meteor.Collection('category');                                                                         // 1
Expenses = new Meteor.Collection('expenses');                                                                         // 2
Total = new Meteor.Collection('total');                                                                               // 3
                                                                                                                      //
ExpensesSchema = new SimpleSchema({                                                                                   // 5
	date: {                                                                                                              // 6
		type: Date,                                                                                                         // 7
		label: 'Expense Date'                                                                                               // 8
	}, // end of date                                                                                                    //
                                                                                                                      //
	cate: {                                                                                                              // 11
		type: String,                                                                                                       // 12
		label: 'Expense Category',                                                                                          // 13
		optional: true                                                                                                      // 14
	}, // end of cate                                                                                                    //
                                                                                                                      //
	subcate: {                                                                                                           // 17
		type: String,                                                                                                       // 18
		label: 'Expense Subcategory',                                                                                       // 19
		optional: true                                                                                                      // 20
	}, // end of subcate                                                                                                 //
                                                                                                                      //
	comment: {                                                                                                           // 23
		type: String,                                                                                                       // 24
		label: 'Expense Details'                                                                                            // 25
	}, // end of comment                                                                                                 //
                                                                                                                      //
	expense: {                                                                                                           // 28
		type: Number,                                                                                                       // 29
		decimal: true,                                                                                                      // 30
		label: 'Expense Value'                                                                                              // 31
	}, // end of date                                                                                                    //
	user: {                                                                                                              // 33
		type: String,                                                                                                       // 34
		label: 'User Id'                                                                                                    // 35
	}, // end of user                                                                                                    //
	checked: {                                                                                                           // 37
		type: Boolean,                                                                                                      // 38
		label: 'Checked or Unchecked'                                                                                       // 39
	} }); // end of SimpleSchema                                                                                         //
                                                                                                                      //
// end of user                                                                                                        //
Expenses.attachSchema(ExpensesSchema);                                                                                // 43
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"publication.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publication.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.publish('total', function () {                                                                                 // 1
	return Total.find({ user: this.userId });                                                                            // 2
}); // end of Metor.publish                                                                                           //
                                                                                                                      //
Meteor.publish('expenses', function (filters_date, cate, subcate) {                                                   // 5
	gte = new Date(moment(filters_date).format('ddd MMM DD YYYY h:mm:ss ZZ z'));                                         // 6
	lt = new Date(moment(filters_date).add(1, 'y').format('ddd MMM DD YYYY h:mm:ss ZZ z'));                              // 7
	if (cate == 'ALL') {                                                                                                 // 8
		return Expenses.find({ 'date': { $gte: gte, $lt: lt }, user: this.userId });                                        // 9
		// cate = ""; subcate = ""                                                                                          //
		// return Meteor.subscribe('expenses', Session.get('filters_date'), cate, subcate)                                  //
	} else if (cate != 'ALL' && subcate == 'ALL') {                                                                      // 8
			// cate = Session.get('filters_cat_value'); subcate = ""                                                           //
			// return Meteor.subscribe('expenses', Session.get('filters_date'), cate, subcate)                                 //
			return Expenses.find({ 'date': { $gte: gte, $lt: lt }, cate: cate, user: this.userId });                           // 16
		} else {                                                                                                            //
			//cate = Session.get('filters_cat_value'); subcate = Session.get('filters_subcat_value')                           //
			//return Meteor.subscribe('expenses', Session.get('filters_date'), cate, subcate)                                  //
			return Expenses.find({ 'date': { $gte: gte, $lt: lt }, cate: cate, subcate: subcate, user: this.userId });         // 21
		}                                                                                                                   //
});                                                                                                                   //
                                                                                                                      //
Meteor.publish('category', function () {                                                                              // 26
	return Category.find({ user: this.userId });                                                                         // 27
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({                                                                                                      // 1
	totalSum: function () {                                                                                              // 2
		function totalSum(filter, userId) {                                                                                 // 2
			if (userId == Meteor.userId()) {                                                                                   // 3
				// Create a group for aggregation                                                                                 //
				group = {                                                                                                         // 5
					_id: {                                                                                                           // 6
						cate: '$cate'                                                                                                   // 7
					},                                                                                                               //
					total: {                                                                                                         // 9
						$sum: '$expense'                                                                                                // 10
					}                                                                                                                //
				};                                                                                                                //
				// Create a new filter based on scenarios                                                                         //
				filter1 = {                                                                                                       // 3
					date: {                                                                                                          // 15
						$gte: new Date(filter.date),                                                                                    // 16
						$lt: new Date(moment(filter.date).add(1, 'y').format('ddd MMM DD YYYY h:mm:ss ZZ z'))                           // 17
					},                                                                                                               //
					cate: filter.cate,                                                                                               // 19
					subcate: filter.subcate,                                                                                         // 20
					user: Meteor.userId()                                                                                            // 21
				};                                                                                                                //
                                                                                                                      //
				// If the Category Chosen is ALL then we delete the cate field from the filter                                    //
				if (filter.cate === 'ALL') {                                                                                      // 3
					delete filter1.cate;                                                                                             // 26
				}                                                                                                                 //
                                                                                                                      //
				// If the Subcategory Chosen is ALL then we delete the subcate field from the filter                              //
				if (filter.subcate === 'ALL') {                                                                                   // 3
					// group._id.subcate = ''                                                                                        //
					delete filter1.subcate;                                                                                          // 32
				}                                                                                                                 //
                                                                                                                      //
				// if a category has been chosen then we add subcategory to the group to get aggragates for all the subcategories
				if (filter.cate != 'ALL') {                                                                                       // 3
					group._id.subcate = '$subcate';                                                                                  // 37
				}                                                                                                                 //
                                                                                                                      //
				// We use Mongo aggregation to aggregat the data                                                                  //
				totals = Expenses.aggregate([{ $match: filter1 }, { $group: group }, { $sort: { total: -1 } }]);                  // 3
				// The _id filed is an objecct. The following code creates a new object with cate, subcate and total fields       //
				totalList = [];                                                                                                   // 3
				_(totals).each(function (total) {                                                                                 // 44
					if (total._id.subcate == undefined) {                                                                            // 45
						total._id.subcate = 'ALL';                                                                                      // 46
					}                                                                                                                //
					totalList = totalList.concat({                                                                                   // 48
						cate: total._id.cate,                                                                                           // 49
						subcate: total._id.subcate,                                                                                     // 50
						total: total.total                                                                                              // 51
					});                                                                                                              //
				});                                                                                                               //
                                                                                                                      //
				agg_cate = Category.find({}, { fields: { _id: 0, cate: 1 } }).fetch();                                            // 55
				// The following if statement is added to avoid an error when returning totalList1.                               //
				// The error is due to the fact agg_cate is null hence totalList1 does not get initialized                        //
				if (agg_cate.length < 1) {                                                                                        // 3
					totalList1 = new Array();                                                                                        // 59
				} else {                                                                                                          //
					_(agg_cate).each(function (cate) {                                                                               // 62
                                                                                                                      //
						// THIS IS USED FOR PIE CHARTS                                                                                  //
						totalList1 = new Array();                                                                                       // 65
						drillList = new Array();                                                                                        // 66
						_(totalList).each(function (total1) {                                                                           // 67
							// if subcate is chosen then we want to show                                                                   //
							if (total1.subcate != 'ALL') {                                                                                 // 69
								cate = total1.subcate;                                                                                        // 70
							} else {                                                                                                       //
								cate = total1.cate;                                                                                           // 73
							}                                                                                                              //
							totalList1.push([cate, total1.total]);                                                                         // 76
							drillList.push([total1.subcate, total1.total]);                                                                // 80
						}); // end of _(totalList).each(function(total1)	                                                               //
					}); // end of _(agg_cate).each(function(cate)	                                                                   // 62
				}                                                                                                                 // 61
                                                                                                                      //
				// The first List returned is for table view and 2nd list is for Pie Chart view                                   //
                                                                                                                      //
				return { total: totalList, pieTotal: totalList1 };                                                                // 3
			} // end of if for userId check                                                                                    //
		}                                                                                                                   //
                                                                                                                      // 2
		return totalSum;                                                                                                    //
	}(),                                                                                                                 //
	reutrn_exp: function () {                                                                                            // 94
		function reutrn_exp(date, cate, subcate, comment, expense, user) {                                                  // 94
			if (user == Meteor.userId()) {                                                                                     // 95
				if (cate === "Choose Category") {                                                                                 // 96
					cate = '';                                                                                                       // 97
					subcate = '';                                                                                                    // 98
				}                                                                                                                 //
				Expenses.insert({                                                                                                 // 100
					date: date,                                                                                                      // 101
					cate: cate,                                                                                                      // 102
					subcate: subcate,                                                                                                // 103
					comment: comment,                                                                                                // 104
					expense: Number(expense),                                                                                        // 105
					user: Meteor.userId(),                                                                                           // 106
					checked: false                                                                                                   // 107
				}); // end of Expense.insert                                                                                      //
			}                                                                                                                  // 95
		}                                                                                                                   //
                                                                                                                      //
		return reutrn_exp;                                                                                                  //
	}(), // end of reutrn_exp:function()                                                                                 //
                                                                                                                      //
	del_exp: function () {                                                                                               // 113
		function del_exp(exp_id, user) {                                                                                    // 113
			if (user == Meteor.userId()) {                                                                                     // 114
				if (Expenses.findOne({ _id: exp_id }).user == Meteor.userId()) {                                                  // 115
					Expenses.remove({ _id: exp_id });                                                                                // 116
				} else {                                                                                                          //
					throw new Meteor.Error('This expense does not belong to user');                                                  // 118
				}                                                                                                                 //
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return del_exp;                                                                                                     //
	}(), // end of del_exp:function(exp_id)                                                                              //
                                                                                                                      //
	del_checked_exp: function () {                                                                                       // 123
		function del_checked_exp() {                                                                                        // 123
			Expenses.remove({ checked: true });                                                                                // 124
		}                                                                                                                   //
                                                                                                                      //
		return del_checked_exp;                                                                                             //
	}(), // end of del_checked_exp:function(exp_id)                                                                      //
                                                                                                                      //
	save_editedExp: function () {                                                                                        // 127
		function save_editedExp(id, date, cate, subcate, comment, expense, user) {                                          // 127
			if (user == Meteor.userId()) {                                                                                     // 128
				if (Expenses.findOne({ _id: id }).user == Meteor.userId()) {                                                      // 129
					Expenses.update(id, { $set: {                                                                                    // 130
							// date:date,                                                                                                  //
							cate: cate,                                                                                                    // 134
							subcate: subcate,                                                                                              // 135
							comment: comment,                                                                                              // 136
							expense: Number(expense),                                                                                      // 137
							user: user                                                                                                     // 138
						} });                                                                                                           //
				} else {                                                                                                          //
					throw new Meteor.Error('This expense does not belong to user');                                                  // 142
				}                                                                                                                 //
			} // end if user check                                                                                             //
		}                                                                                                                   // 127
                                                                                                                      //
		return save_editedExp;                                                                                              //
	}(), // end of save_editedExp                                                                                        //
                                                                                                                      //
	parseUpload: function () {                                                                                           // 146
		function parseUpload(data, userid) {                                                                                // 146
			categories = Category.find();                                                                                      // 147
			for (i = 0; i < data.length; i++) {                                                                                // 148
				item = data[i], catList = [];                                                                                     // 149
				subcatList = [];                                                                                                  // 151
				categories.forEach(function (category) {                                                                          // 152
					if (item.cate === category.cate) {                                                                               // 153
						catList = catList.concat(item.cate);                                                                            // 154
						if (category.subcate.indexOf(item.subcate) != -1) {                                                             // 155
							subcatList = subcatList.concat(item.subcate);                                                                  // 156
						}                                                                                                               //
					} else {                                                                                                         //
						console.log('THRE IS NO MATCH FOR CATEGORY');                                                                   // 160
					}                                                                                                                //
				});                                                                                                               //
				if (catList.length < 1) {                                                                                         // 163
					item.cate = '';                                                                                                  // 164
					item.subcate = '';                                                                                               // 165
				} else if (subcatList.length < 1) {                                                                               //
					item.subcate = '';                                                                                               // 168
				}                                                                                                                 //
				Expenses.insert({                                                                                                 // 170
					date: new Date(item.date),                                                                                       // 171
					cate: item.cate,                                                                                                 // 172
					subcate: item.subcate,                                                                                           // 173
					comment: item.comment,                                                                                           // 174
					expense: Number(item.expense),                                                                                   // 175
					user: Meteor.userId(),                                                                                           // 176
					checked: false                                                                                                   // 177
				}); // end of Expense.insert                                                                                      //
			} // end of for loop                                                                                               //
		}                                                                                                                   // 146
                                                                                                                      //
		return parseUpload;                                                                                                 //
	}(), // end of parseUpload:function(data)                                                                            //
                                                                                                                      //
	yearSnapshot: function () {                                                                                          // 183
		function yearSnapshot(filter, userid) {                                                                             // 183
			if (userid == Meteor.userId()) {                                                                                   // 184
				// For charting data across months Jan thru Dec we structure the data in a specific format and put it in a new Collection called Total
				// Step 1: We gather all the categories                                                                           //
				agg_cate = Category.find({ user: Meteor.userId() }, { fields: { _id: 0, cate: 1 } }).fetch();                     // 187
				// Step 2: We define month names to numbers mapping since our aggrgation returns month numbers                    //
				months = { 1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr', 5: 'May', 6: 'Jun', 7: 'Jul', 8: 'Aug', 9: 'Sep', 10: 'Oct', 11: 'Nov', 12: 'Dec' };
                                                                                                                      //
				// Dump the database and re-calculate to ensure new data is reflected                                             //
				Total.remove({ user: Meteor.userId() });                                                                          // 184
				// Loop through each category (filter) and get the aggregated result for a category for every month in a year     //
				total1 = new Array();                                                                                             // 184
				_(agg_cate).each(function (cate) {                                                                                // 195
					totalMonth = Expenses.aggregate([{ $match: { user: Meteor.userId(), date: { $gte: new Date(filter.date), $lt: new Date(moment(filter.date).add(1, 'y').format('ddd MMM DD YYYY h:mm:ss ZZ z')) }, cate: cate.cate } }, { $group: { _id: { month: { $month: "$date" } }, total: { $sum: "$expense" } } }]);
					// Map the month id to the total value for the category                                                          //
					totalArray = {};                                                                                                 // 195
					_(totalMonth).each(function (tot) {                                                                              // 199
                                                                                                                      //
						for (monId in meteorBabelHelpers.sanitizeForInObject(months)) {                                                 // 201
							if (monId == tot._id.month) {                                                                                  // 202
								totalArray[monId] = tot.total;                                                                                // 203
							} // enf of for monId			                                                                                       //
						}                                                                                                               // 201
					}); // end of _totalMonth function                                                                               //
					// Create an array of 12 values. Each position in the array reflects the total for that month. Required by Highcharts for column graphs
					b = [];                                                                                                          // 195
					for (i = 1; i <= 12; i++) {                                                                                      // 209
						if (totalArray[i] == undefined) {                                                                               // 209
							totalArray[i] = 0;                                                                                             // 209
						}b.push(totalArray[i]);                                                                                         //
					}                                                                                                                //
					// For every category insert the category name and the new array created. The words name and data are for imp. highchart looks for those names
					Total.insert({                                                                                                   // 195
						name: cate.cate,                                                                                                // 212
						data: b,                                                                                                        // 213
						user: Meteor.userId()                                                                                           // 214
					}); // end of Total.insert                                                                                       //
				}); // end of _(agg_cate).each(function(cate)                                                                     //
			}                                                                                                                  // 184
		}                                                                                                                   //
                                                                                                                      //
		return yearSnapshot;                                                                                                //
	}(), // end of yearSnapshot:function(filter)                                                                         //
                                                                                                                      //
	updateExpenseCat: function () {                                                                                      // 223
		function updateExpenseCat(cate, subcate) {                                                                          // 223
			ids = Expenses.find({ checked: true }).fetch();                                                                    // 224
			_(ids).each(function (id) {                                                                                        // 225
				Expenses.update({ _id: id._id }, { $set: { cate: cate, subcate: subcate, checked: false } });                     // 226
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return updateExpenseCat;                                                                                            //
	}(), // end of updateExpenseCat                                                                                      //
                                                                                                                      //
	checkExpenses: function () {                                                                                         // 231
		function checkExpenses(id, checked) {                                                                               // 231
			Expenses.update(id, {                                                                                              // 232
				$set: { checked: !checked }                                                                                       // 233
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return checkExpenses;                                                                                               //
	}(), // end of limitedExpenses                                                                                       //
	newcatInsert: function () {                                                                                          // 236
		function newcatInsert(cat_value, userid) {                                                                          // 236
			if (userid == Meteor.userId()) {                                                                                   // 237
				if (!cat_value) {                                                                                                 // 238
					throw new Meteor.Error('Please enter a valid String');                                                           // 239
				} else if (Category.find({ user: Meteor.userId(), cate: { $in: [cat_value] } }).count() != 0) {                   //
					throw new Meteor.Error('Category ' + cat_value + ' Already exists');                                             // 242
				} else {                                                                                                          //
					Category.insert({                                                                                                // 245
						cate: cat_value,                                                                                                // 246
						subcate: [],                                                                                                    // 247
						user: Meteor.userId()                                                                                           // 248
					});                                                                                                              //
				}                                                                                                                 //
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return newcatInsert;                                                                                                //
	}(), // end of newcatInsert                                                                                          //
	newsubcateInsert: function () {                                                                                      // 254
		function newsubcateInsert(cat_id, subcat_list, userid) {                                                            // 254
			if (userid == Meteor.userId()) {                                                                                   // 255
				Category.update({ _id: cat_id }, { $set: { subcate: subcat_list } });                                             // 256
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return newsubcateInsert;                                                                                            //
	}()                                                                                                                  //
                                                                                                                      //
}); // end of Meteor.methods                                                                                          //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"shared":{"main.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// shared/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
TabularTables = {};                                                                                                   // 1
                                                                                                                      //
TabularTables.Expenses = new Tabular.Table({                                                                          // 3
  name: "Expenses",                                                                                                   // 4
  collection: Expenses,                                                                                               // 5
  columns: [{ data: "checked", title: "Checked", visible: false }, { tmpl: Meteor.isClient && Template.checkBoxes, title: 'Select', "class": "col-md-1",
    tmplContext: function () {                                                                                        // 9
      function tmplContext(rowData) {                                                                                 // 9
        return {                                                                                                      // 10
          item: rowData                                                                                               // 11
        };                                                                                                            //
      }                                                                                                               //
                                                                                                                      //
      return tmplContext;                                                                                             //
    }()                                                                                                               //
  }, { data: 'date', render: function () {                                                                            //
      function render(data) {                                                                                         // 15
        return moment(data).format('MM/DD/YYYY');                                                                     // 15
      }                                                                                                               //
                                                                                                                      //
      return render;                                                                                                  //
    }(), title: "Date" }, { data: "cate", title: "Category" }, { data: "subcate", title: "Subcategory" }, { data: "comment", title: "Description" }, { data: "expense", title: "Expense" }, { tmpl: Meteor.isClient && Template.upDelexp, title: 'Upate', "class": "col-md-1" }],
  selector: function () {                                                                                             // 22
    function selector(userId) {                                                                                       // 22
      return { user: userId };                                                                                        // 23
    }                                                                                                                 //
                                                                                                                      //
    return selector;                                                                                                  //
  }()                                                                                                                 //
});                                                                                                                   //
                                                                                                                      //
function formatDate(date) {                                                                                           // 27
  return moment(date).format('MM/DD/YYYY');                                                                           // 28
};                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/collections.js");
require("./server/publication.js");
require("./server/main.js");
require("./shared/main.js");
//# sourceMappingURL=app.js.map
